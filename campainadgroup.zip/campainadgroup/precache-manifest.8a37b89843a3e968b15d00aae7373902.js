self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "52abb86e0d736a68bd83b7b37737cfac",
    "url": "/cerebralex-dashboard/index.html"
  },
  {
    "revision": "fe56f2f8b2c33307fb90",
    "url": "/cerebralex-dashboard/static/css/main.b2233793.chunk.css"
  },
  {
    "revision": "f6712b1344e9706ae841",
    "url": "/cerebralex-dashboard/static/js/2.35fc34e3.chunk.js"
  },
  {
    "revision": "3a5359d431b8190dc2f36e4703f39768",
    "url": "/cerebralex-dashboard/static/js/2.35fc34e3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fe56f2f8b2c33307fb90",
    "url": "/cerebralex-dashboard/static/js/main.76e915c9.chunk.js"
  },
  {
    "revision": "ace457595cdb2b4e9b2f",
    "url": "/cerebralex-dashboard/static/js/runtime-main.fa2a4a3f.js"
  },
  {
    "revision": "d858b9233c3f8a5440776e31d7646f7f",
    "url": "/cerebralex-dashboard/static/media/accounts-color.d858b923.svg"
  },
  {
    "revision": "ad00869fc0325e1b9880095ed3570fe5",
    "url": "/cerebralex-dashboard/static/media/accounts.ad00869f.svg"
  },
  {
    "revision": "c49b471ad5f5e64c25d25d959375d4c5",
    "url": "/cerebralex-dashboard/static/media/analytics-color.c49b471a.svg"
  },
  {
    "revision": "07c9c2fdaebcec049512600a31dfc8b3",
    "url": "/cerebralex-dashboard/static/media/analytics.07c9c2fd.svg"
  },
  {
    "revision": "c5f38d7d25add1ebab187553b7154b57",
    "url": "/cerebralex-dashboard/static/media/campaigns-color.c5f38d7d.svg"
  },
  {
    "revision": "013fc6358c680238ee2da066d8a18d29",
    "url": "/cerebralex-dashboard/static/media/campaigns.013fc635.svg"
  },
  {
    "revision": "6776d364806dd4e43a44a37a4356eafe",
    "url": "/cerebralex-dashboard/static/media/dashboard-default.6776d364.svg"
  },
  {
    "revision": "834792270f4d3824ee56d5edefa0c7a9",
    "url": "/cerebralex-dashboard/static/media/dashboard.83479227.svg"
  },
  {
    "revision": "47d9df8b5ede9638816df0dbdb3ca52d",
    "url": "/cerebralex-dashboard/static/media/history-color.47d9df8b.svg"
  },
  {
    "revision": "e6859ea49923d3e24711e64ea2e7cefd",
    "url": "/cerebralex-dashboard/static/media/history.e6859ea4.svg"
  },
  {
    "revision": "9ff4282f51a94e1e237c334d21ec9d9c",
    "url": "/cerebralex-dashboard/static/media/library-color.9ff4282f.svg"
  },
  {
    "revision": "478026bebe36007fbd4b68306e8a2cef",
    "url": "/cerebralex-dashboard/static/media/library.478026be.svg"
  },
  {
    "revision": "c4f9269cdd5559a37323ee12d3fc3bbc",
    "url": "/cerebralex-dashboard/static/media/logo.c4f9269c.svg"
  }
]);